:mod:`similarities.docsim` -- Document similarity queries
========================================================================

.. automodule:: gensim.similarities.docsim
    :synopsis: Document similarity queries
    :members:
    :inherited-members:

