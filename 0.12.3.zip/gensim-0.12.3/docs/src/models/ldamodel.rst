:mod:`models.ldamodel` -- Latent Dirichlet Allocation
======================================================

.. automodule:: gensim.models.ldamodel
    :synopsis: Latent Dirichlet Allocation
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
