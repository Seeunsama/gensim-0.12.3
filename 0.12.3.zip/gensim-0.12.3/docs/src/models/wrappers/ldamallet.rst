:mod:`models.wrappers.ldamallet` -- Latent Dirichlet Allocation via Mallet
==========================================================================

.. automodule:: gensim.models.wrappers.ldamallet
    :synopsis: Latent Dirichlet Allocation via Mallet
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
