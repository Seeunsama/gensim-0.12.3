:mod:`models.wrappers.ldavowpalwabbit` -- Latent Dirichlet Allocation via Vowpal Wabbit
=======================================================================================

.. automodule:: gensim.models.wrappers.ldavowpalwabbit
    :synopsis: Latent Dirichlet Allocation via Vowpal Wabbit
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
