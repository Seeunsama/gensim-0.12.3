:mod:`models.phrases` -- Phrase (collocation) detection
=======================================================

.. automodule:: gensim.models.phrases
    :synopsis: Phrase (collocation) detection
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
