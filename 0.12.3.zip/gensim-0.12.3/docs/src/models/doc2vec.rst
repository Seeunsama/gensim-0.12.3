:mod:`models.doc2vec` -- Deep learning with paragraph2vec
=========================================================

.. automodule:: gensim.models.doc2vec
    :synopsis: Deep learning with doc2vec
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
