:mod:`models.ldamulticore` -- parallelized Latent Dirichlet Allocation
======================================================================

.. automodule:: gensim.models.ldamulticore
    :synopsis: Latent Dirichlet Allocation
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
