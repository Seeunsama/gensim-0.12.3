:mod:`models.lda_dispatcher` -- Dispatcher for distributed LDA
================================================================

.. automodule:: gensim.models.lda_dispatcher
    :synopsis: Dispatcher for distributed LDA
    :members:
    :inherited-members:

