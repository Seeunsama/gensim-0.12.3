:mod:`models.hdpmodel` -- Hierarchical Dirichlet Process
========================================================

.. automodule:: gensim.models.hdpmodel
    :synopsis: Hierarchical Dirichlet Process
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
